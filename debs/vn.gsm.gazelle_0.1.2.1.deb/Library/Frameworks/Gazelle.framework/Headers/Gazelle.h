
#import <SpringBoard/SBApplicationController.h>
#import <SpringBoard/SBApplicationIcon.h>
#import <SpringBoard/SBDockView.h>
#import <SpringBoard/SBIconController.h>
#import <SpringBoard/SBIconListView.h>
#import <SpringBoard/SBIconModel.h>
#import <SpringBoard/SBIconView.h>
#import <SpringBoard/SBRootFolderView.h>
#import <SpringBoard/SBRootFolderController.h>
#import <SpringBoard/SBUIController.h>
#import <SpringBoard/SpringBoard.h>
#import <UIKit/UIApplication+Private.h>
#import <version.h>
#import <AudioToolbox/AudioToolbox.h>
#include <dlfcn.h>

@interface SBIconViewMap
+(id)homescreenMap;
-(id)mappedIconViewForIcon:(id)arg1 ;
@end

@interface SBIconController (iOS93)
@property(readonly, nonatomic) SBIconViewMap *homescreenIconViewMap;
@end

@interface CPGPresentationWindow
+ (instancetype)sharedWindow;
- (BOOL)preventsVolumeHUDPresentation;
- (void)setPreventsVolumeHUDPresentation:(BOOL)prevents;
- (void)tearDownAnimated:(BOOL)animated;
@end

static int const UITapticEngineFeedbackPeek = 1001;
static int const UITapticEngineFeedbackPop = 1002;
@interface UITapticEngine : NSObject
- (void)actuateFeedback:(int)arg1;
- (void)endUsingFeedback:(int)arg1;
- (void)prepareUsingFeedback:(int)arg1;
@end
@interface UIDevice (Private)
-(UITapticEngine*)_tapticEngine;
@end

@interface Gazelle : NSObject
+ (void)fadeIconForIdentifier:(NSString *)identifier toAlpha:(CGFloat)alpha withDuration:(CGFloat)duration;
+ (void)fadeInAppIconsWithDuration:(CGFloat)duration;
+ (void)fadeOutAppIconsTo:(CGFloat)fadeAmount withDuration:(CGFloat)duration;
+ (void)openApplicationForBundleIdentifier:(NSString *)identifier;
+ (void)preventVolumeHUDPresentation:(BOOL)prevents;
+ (void)simulateHapticFeedbackOfType:(int)type;
+ (void)tearDownAnimated:(BOOL)animated;
+ (void)updateStatusBarHidden:(BOOL)hidden;
@end
