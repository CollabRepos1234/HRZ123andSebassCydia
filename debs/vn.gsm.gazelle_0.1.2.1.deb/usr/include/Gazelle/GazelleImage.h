
@interface GazelleImage : NSObject
+ (UIImage*)imageNamed:(NSString *)name fromBundle:(NSBundle *)bundle;
@end
