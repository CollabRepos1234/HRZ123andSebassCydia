@interface GazelleDate : NSObject
/**
* returns 5m
*/
+ (NSString *)shortTimeAgoStringForDate:(NSDate *)date;
/**
* return 5 minutes ago
*/
+ (NSString *)timeAgoStringForDate:(NSDate *)date;
@end
