
@interface GazelleCamera : NSObject
/**
* When you want to keep your camera view looking stock, might as well use stock assets
* Available images include: CAMFilterButton, CAMFilterButtonOn CAMFlashBadge, CAMFlashButton
* CAMFlashButtonOff, CAMFlashDisabled_2only_, CAMFlipButton, CAMFramerateIndicatorBadge,
* CAMHDRBadge, CAMHDRButton, CAMHDRButtonOff, CAMImageWellMask, CAMModeDialDot,
* CAMRecordingDot, CAMShutterButtonSlomo, CAMShutterButtonTimelapse, CAMTimerButton,
* CAMZoomSliderMinus, CAMZoomSliderPlus, CAMZoomSliderThumb, CAMZoomSliderTrack
* CAMCameraFaceRoundedRectangle, PLCameraFaceRoundedRectangle, PLCameraPreviewPlaceholder,
* CPLFocusCrosshairs, PLFocusCrosshairsSmall, firebreak-PLCameraPanoramaArrowHead_2only_
*/
+ (UIImage*)cameraImageForImageName:(NSString *)name;
@end
