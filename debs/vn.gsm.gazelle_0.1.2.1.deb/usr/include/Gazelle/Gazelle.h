

@interface Gazelle : NSObject
/**
* This will launch the application corresonding the identifer passed
* Usually used in the handling of the icon view tap
* By default when this is called the block will be removed
*/
+ (void)openApplicationForBundleIdentifier:(NSString *)identifier;

/**
*	Used to change the alpha of one icon without affecting the rest
*/
+ (void)fadeIconForIdentifier:(NSString *)identifier toAlpha:(CGFloat)alpha withDuration:(CGFloat)duration;

/**
* This is used to fade icons back in after they have been hidden
*/
+ (void)fadeInAppIconsWithDuration:(CGFloat)duration;

/**
* Used to fade out icons and dock to bring attention to whatever you are
* presenting to the user. If you do call this, make sure to stop the user
* from being able to change HS page, otherwise fading in might not fade in
* the icons you previously faded out
*/
+ (void)fadeOutAppIconsTo:(CGFloat)fadeAmount withDuration:(CGFloat)duration;

/**
* If creating views which change system volume you may not want the volume
* HUD to pop up. This will handle that for you. Don't forget to turn
* it back on once you're doing your stuff.
*/
+ (void)preventVolumeHUDPresentation:(BOOL)prevents;

/**
* Simulate the feeling of Haptic Feedback
* Ofc uses the real deal on 6s/6s+
*/

+ (void)simulateHapticFeedbackOfType:(int)type;

/**
* If you need to remove the view, do this
*/
+ (void)tearDownAnimated:(BOOL)animated;

/**
* Simple, sometimes you may need to hide the status bar
*/
+ (void)updateStatusBarHidden:(BOOL)hidden;
@end
