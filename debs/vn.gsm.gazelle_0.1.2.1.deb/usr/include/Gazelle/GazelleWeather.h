
@interface GazelleWeather : NSObject
/**
* Localization really makes a big different in making your tweaks accessible to all users
* By passing a weather condition code this will give you the localized weather condition
*/
+ (NSString *)localizedWeatherNameForCondition:(int)condition;

/**
* Creating animated weather background involves reading the .caml file in the Weather.framework (iOS 7+8)
* or WeatherUI.framework iOS 9+. This will give you the file location for the condition passed
* it's up to you to parse the caml file.
*/
+ (NSURL *)CAMLFilenameForWeatherCondition:(int)condition isDay:(BOOL)day;

/**
* This will provide you with the image corresponding the weather condition passed
*/
+ (UIImage *)weatherIconForCondition:(int)condition isDay:(BOOL)isDay wantsLargerIcons:(BOOL)larger;
@end
